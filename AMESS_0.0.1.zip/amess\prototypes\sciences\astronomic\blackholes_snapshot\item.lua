data:extend({
    {
        type = "item",
        name = "blackholes-snapshot",
        icon = "__amess__/graphics/icons/blank_64.png",
        icon_size = 64,
        subgroup = "science-pack",
        order = "a[blackholes-snapshot]",
        stack_size = 200
    }
})