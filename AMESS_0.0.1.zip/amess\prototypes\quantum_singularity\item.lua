data:extend({
  {
    type = "item",
    name = "quantum-singularity",
    icon = "__amess__/graphics/icons/quantum-singularity.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "astro-subgroup",
    order = "a[quantum-singularity]",
    stack_size = 1000
  }
})
