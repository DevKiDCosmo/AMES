data:extend({
    {
      type = "item",
      name = "my-new-machine",
      icon = "__amess__/graphics/icons/assembly.png",
      icon_size = 64,
      subgroup = "production-machine",
      order = "a[my-new-machine]",
      place_result = "my-new-machine",
      stack_size = 50
    }
  })
  