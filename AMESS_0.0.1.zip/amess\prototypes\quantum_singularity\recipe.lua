data:extend({
  {
    type = "recipe",
    name = "quantum-singularity",
    ingredients = {
      {type = "item", name = "iron-plate", amount = 2}
    },
    results = {
      {type = "item", name = "quantum-singularity", amount = 1}
    },
  }
})
