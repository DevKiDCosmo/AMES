data:extend({
    {
        type = "recipe",
        name = "blackholes-snapshot",
        enabled = false,
        energy_required = 10,
        ingredients = {
            {type = "item", name = "iron-plate", amount = 1},
            {type = "item", name = "copper-plate", amount = 1}
        },
        results = {
            {type = "item", name = "blackholes-snapshot", amount = 1}
        }
    }
})